package com.example.tutorials.Tutorials;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TutorialsApplicationTests {

	@Test
	void contextLoads() {
	}

}
